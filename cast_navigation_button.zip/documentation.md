# Cast Navigation Button
* Version: 1.0
* Requirement: Qlik Sense June 2017

## Documentation
### 1. Overview
![image](./overview.png)
### 2. Basic Settings

| Property       | Description                              |
| -------------- | ---------------------------------------- |
| Button Text    | Text shown on the button, support font-awesome^1^ |
| Button Class   | Pre-defined button style                 |
| Button Color   | Background color of the button           |
| Font Color     | Font color of the button                 |
| Font Size      | Font size (Integer)                      |
| Custom CSS     | customise the style of the button (border, radius etc.)^3^ |
| Sheet Selector | Link to another page                     |

1. To use Font-awesome icons:
    * See http://fontawesome.io/icons/ for supported icons
    * Copy the code provided to the Button Text to insert an icon

    ​
2. For Custom CSS: useful properties

| Key Properties | Value                                   |
| -------------- | --------------------------------------- |
| border-radius  | border-radius:3px;                      |
| border         | border:3px solid blue;                  |
| border-style   | border-style:solid dotted dashed double |

---

## Examples
* **Example 1**

| Key Properties | Value                                    |
| -------------- | ---------------------------------------- |
| Button Text    | Sales Analysis <i class="fa fa-film" aria-hidden="true"></i> |
| Font Size      | 50                                       |
| Custom CSS     | border-radius:30px;                      |
![image](example1.png)

---

* **Example 2**

| Key Properties | Value                                    |
| -------------- | ---------------------------------------- |
| Button Text    | Sales Analysis <i class="fa fa-film" aria-hidden="true"></i> |
| Font Size      | 50                                       |
| Custom CSS     | border-radius:30px;border:6px solid RoyalBlue; border-style:solid hidden solid hidden; |
![image](example2.png)