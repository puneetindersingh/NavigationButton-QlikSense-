define(["jquery","text!./scoped-bootstrap.css","qlik"],function ($,cssContent,qlik){
        'use strict';
$("<style>").html(cssContent).appendTo("head");
    return {
        definition : {      
            type: "items",
            component: "accordion",
            items: {appearance:{
                    uses: "settings",
                    items: {
                        DropDownA: {
                            type: "string",
                            component: "sheet-dropdown",
                            label: "Sheet Selector",
                            ref: "PageSelector",
                            type: "string",
                            },
                    	ButtonStyle_Section:{
                    		type: "items",
                    		label: "Button Settings",
                    		items:{
	                        TextBoxB: {
	                            ref: "ButtonLabel",
	                            label: "Button Text",
	                            type: "string",
	                            component: "textarea",
	                            defaultValue: "undefined",
	                            },
	                        DropDownB: {
	                            type: "string",
		                        component: "dropdown",
	                            label: "Button Class",
	                            ref: "ButtonClass",
	                            options:[
	                            {'label':'None','value':''},
	                            {'label':'Primary','value':'btn-primary'},
	                            {'label':'Secondary','value':'btn-secondary'},
	                            {'label':'Success','value':'btn-success'},
	                            {'label':'Danger','value':'btn-danger'},
	                            {'label':'Warning','value':'btn-warning'},
	                            {'label':'Info','value':'btn-info'},
	                            {'label':'Link','value':'btn-link'},
	                            ],
	                            defaultValue: "btn-secondary",
	                            },
                    		ColorA:{
                    				label:"Button Color",
					                ref: "Buttoncolor",
					                type: "object",
					                component: "color-picker",
					                dualOutput: !0,
					                defaultValue:{index: 15, color: "#000000"},
					              },
                    		ColorB:{
                    				label:"Font Color",
					                ref: "Fontcolor",
					                type: "object",
					                component: "color-picker",
					                dualOutput: !0,
					                defaultValue:{index: 1, color: "#ffffff"},
					              },
	                        TextBoxC: {
	                            ref: "Fontsize",
	                            label: "Font Size",
	                            type: "string",
	                            //defaultValue: "undefined",
	                            },

	                        TextBoxE: {
	                            ref: "Style",
	                            label: "Custom CSS",
	                            component: "textarea",
	                            type: "string",
	                            //defaultValue: "undefined",
	                            },			   
	                    	},
                    	},
	                    About_Section: {
                    		type: "items",
                    		label: "About",
                    		items:{
		                        About_TextA: {
		                            label: 'Cast Navigation Button V1.0',
		                            component: "text",
		                            },   
		                        //About_TextB: {
		                        //    label: 'Release Date: 29.Sep.2017',
		                        //    component: "text",
		                        //    },   
		                        About_TextC: {
		                            label: 'Developed by Cast Solutions',
		                            component: "link",
		                            url:"http://www.castsolutions.com.au/"
		                            },
		                        //About_TextD: {
		                        //    label: 'Documentation',
		                        //    component: "link",
		                        //    url:""
		                        //    },
                    		},
                            },
                    }
                        }
                }
            },
        paint: function ($element,layout){
        	//console.log(layout.advanced_color.color);
		    //var btncolor="background-color:"+layout.Buttoncolor+";";
 		    var btncolor="background-color:"+layout.Buttoncolor.color+";";
            var btnlabel=layout.ButtonLabel;
            var fntcolor="color:"+layout.Fontcolor.color+";";
            $element.html("<head><meta charset='utf-8'><script src='https://use.fontawesome.com/7c3ee51946.js'></script></head>");
            var font_size="font-size:"+layout.Fontsize+"px;";
            var btnid=Math.round(Math.random()*10000);
            console.log(layout.Fontcolor);
 			//var app = qlik.currApp();
            //$element.append("<div class='bootstrap_inside' style='height:100%;'><button type='button' class='btn "+layout.ButtonClass+"'' style='height:100%;width:100%;"+font_size+fntcolor+btncolor+layout.Style+"' id="+layout.ButtonID+">"+btnlabel+"</button></div>");
			$element.append("<div class='bootstrap_inside' style='height:100%;'><button type='button' class='btn "+layout.ButtonClass+"'' style='height:100%;width:100%;"+font_size+fntcolor+btncolor+layout.Style+"' id="+btnid+">"+btnlabel+"</button></div>");
            //$("#"+layout.ButtonID).click(function(){
            $("#"+btnid).click(function(){
                var app = qlik.currApp();
                qlik.navigation.gotoSheet(layout.PageSelector);
                });
        }
    };
});
